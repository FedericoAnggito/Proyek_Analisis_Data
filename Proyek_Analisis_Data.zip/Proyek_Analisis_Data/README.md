*pip install numpy pandas scipy matplotlib seaborn jupyter streamlit babel

*streamlit run Dashboard.py